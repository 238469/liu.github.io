<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php 
        $uid=$_GET['uid'];
        $username=$_GET['username'];
        
    ?>
    <script src='../tinymce/xixi/hah/tinymce.min.js'></script>
    <script>
        tinymce.init({
            selector: '#mytextarea'
        });
    </script>

    <script src="./jquery-3.4.1.min.js"></script>
    <script>
        function x() {
            var content=tinymce.activeEditor.getContent();
            var title = $('#title').val();
           
            var rename="title="+title+"&content="+content+"&uid="+<?php  echo $uid  ?>+"&username="+'<?php  echo $username ?>'
              
              $.post(
                 '../php/essay.php',rename,function(data){
                    location.href="../php/catelog1.php?username="+data+""
                
             })
             }

            
    
    </script>
    <style>
        body {
            background-image: url(../../img/v2-5130cfea9846842946b58f303ce3774e_r.jpg);
            background-size: cover
        }

        .on {
            text-align: center;
            margin-top: 10px;
        }

        input {
            width: 200px;
            height: 40px;
        }

        textarea {
            margin-top: 20px
        }
    </style>


</head>

<body>


    <div align="center" style="margin-top:100px;font-size:50px">小说发表</div>
    <div class="on">
        <input type="text" maxlength="13" name="title" id="title" placeholder="标题"><br>
        <textarea name="content" id="mytextarea" cols="100" rows="100" placeholder="输入内容"></textarea><br>
        <input onclick='x()' class="submit" type="submit" value="插入内容">
    </div>
</body>

</html>