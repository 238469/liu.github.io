# -*- coding: utf-8 -*-
# @Time : 2023/6/13 11:54
# @Author : 23
# @Email : 2384693535@qq.com
# @File : web.py
# @Project : pythonProject3
# @脚本说明 :
line_number = [0] # 存放当前读取的日志行数
from flask import Flask,render_template,request,redirect,url_for
import json
from html import escape
app=Flask(__name__)
@app.route('/waf')
def waf():
    str1=''
    with open('ruls', 'r') as fp:
        data = fp.read()
    ruls = json.loads(data)
    for rul in ruls:
       str1+=f"<tr><td>{rul['name']}</td><td>{escape(rul['rul'])}</td><td><button onclick=\"location.href='del?name={rul['name']}'\">删除</button><button onclick=\"location.href='change?name={rul['name']}&rule={rul['rul']}'\">修改</button></td></tr>"
    return render_template('waf.html',rule_name=str1)
@app.route('/del')
def delete_rul():
    name = request.values.get("name")
    with open('ruls', 'r') as fp:
        data = fp.read()
    ruls = json.loads(data)
    for rul in ruls:
        if rul['name']==name:
            ruls.remove(rul)
    ruls=json.dumps(ruls)
    with open('ruls','w')as fp:
        fp.write(ruls)
    return redirect(request.referrer)
@app.route('/change')
def change():
    name = request.values.get("name")
    rule = request.values.get("rule")
    return render_template('change.html', change_name=name,change_rule=rule)
@app.route('/result',methods=['POST'])
def result():
    name=request.form['name']
    rul1=request.form['rul']
    with open('ruls', 'r') as fp:
        data = fp.read()
    ruls = json.loads(data)
    for rul in ruls:
        if rul['name']==name:
            rul['rul']=rul1
    ruls=json.dumps(ruls)
    with open('ruls','w')as fp:
        fp.write(ruls)
    return redirect(url_for("waf"))
@app.route('/add',methods=['POST'])
def add():
    name=request.form['name']
    rul1=request.form['rul']
    with open('ruls', 'r') as fp:
        data = fp.read()
    ruls = json.loads(data)
    ruls.append({'rul':rul1,'name':name})
    rul=json.dumps(ruls)
    with open('ruls','w')as fp:
        fp.write(rul)
    return redirect(url_for("waf"))
@app.route('/log')
def log():
    return render_template('log.html')
@app.route("/get_log")
def get_log():
    # 打开日志文件，读取所有行内容
    with open("log.txt", "r") as f:
        lines = f.readlines()
    # 获取返回的日志列表的长度，并与line_number进行比较
    if len(lines) > line_number[0]:
        # 有新的日志内容，取出新的日志内容
        new_lines = lines[line_number[0]:]
        # 将新的日志内容拼接成一个字符串，并添加换行符
        log_list = "".join([line + "<br>" for line in new_lines])
    else:
        # 没有新的日志内容，返回空字符串
        log_list = ""
    # 删除旧的读取行数，并添加新的读取行数
    line_number.pop()
    line_number.append(len(lines))
    # 返回一个json格式的数据，包含日志内容
    return {"log_list": log_list}
if __name__==('__main__'):
    app.run(host='192.168.150.131', port=5000)
