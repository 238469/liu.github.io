<?php
session_start();
$uid=$_GET['uid'];
$sql="delete from user where uid=$uid";
include 'function.php';
$res=dml($sql);
if ($res==1){
$_SESSION['isLogin']=true;echo "<script>location.href='../html/index.html'</script>";}
?>