<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        
        body{
            background-image:url(../../img/v2-5130cfea9846842946b58f303ce3774e_r.jpg);
            background-size:cover;

        }
        
        img{
        width: 200px;
        height: 200px;
        border-radius: 200px;
        
      } 
      .img{
        
        margin-top: 30px;
        margin-left: 50px;
        
      }     

        #div{
            border:0px solid gray;
            width:600px;
            height: 600px;
            margin:auto;
            margin-top:100px;
          
        }
        #div div{
            border:1px solid gray;
            width:14.5%;
            float:left;
            height:50px;

        }
        a {
      text-decoration: none;
    }
            
    </style>
    <script src="../html/jquery-3.4.1.min.js">
      </Script>
      <script>  function dodel(id){
            var param="id="+id;
            var confirmed=confirm('你确认要删除吗')
            if(confirmed){
            $.post(
                'del.php',param,function(data){
                    if(data=='success'){
                        alert('删除成功')
                    }
                    else{
                        alert('删除失败')
                    }
                    location.reload()
                }
            )
        }

        }
        function doedit(id){
            $.get(
                'edit.php?id='+id,function(data){
                    location.href='edit.php?id='+id
                }
            )
        }
    </script>
</head>
<body>
<?php
// ini_set('log_errors', false);
//error_reporting(E_ALL);
//  error_reporting();
// ini_set('display_errors', 0);
session_start();
  if(@$_SESSION['isLogin']!=1){
   die( "没有登录");
 }

    $username=$_GET['username'];
    $conn = mysqli_connect('localhost', 'root', '', 'test');
if (!$conn) {
    die('连接数据库失败：' . mysqli_connect_error());
}

// 从数据库中获取所有已发布的文章
mysqli_query($conn,"set names utf8");
$sql = "select photo,uid from user where username='$username' ";
$result = mysqli_query($conn, $sql);
foreach($result as $res){
    $uid=$res['uid'];
    $photo=$res['photo'];
}
echo "<div class='img' >头像<br><img src='./upload/$photo' alt=''></div>" ;
echo  "<div><input onclick=location.href='../html/essay.php?uid=$uid&username=$username' type='button' value='发布'></div>";
echo  "<div><input onclick=location.href='../php/logout.php?uid=$uid' type='button' value='注销'></div>"
    ?>
    
    <div id="div">
        <label style="font-size:26px;text-align:center" for="">小说清单</label><br/>
    <div>编号</div>
    <div style="width:40%">标题</div>
    <div>作者</div>
    <div>编辑</div>
    <div>删除</div>
    <?php
//     session_start();
//    if(@$_SESSION['isLogin']!=1){
//     die('未登录');
//    }
    // 连接数据库
$conn = mysqli_connect('localhost', 'root', '', 'test');
if (!$conn) {
    die('连接数据库失败：' . mysqli_connect_error());
}

// 从数据库中获取所有已发布的文章
mysqli_query($conn,"set names utf8");
$sql = "select id,title,username from essay,user where essay.uid=user.uid and username='$username'";

$result = mysqli_query($conn, $sql);
mysqli_close($conn);
foreach($result as $res){
    $id=$res['id'];
    $title=$res['title'];
    $author=$res['username'];
    echo "<div><a href=\"article.php?id='$id'\">$id</a></div>";
    echo "<div style='width:40%'><a href=\"details.php?id=$id\">$title</a></div>";
    echo "<div>$author</div>";
    echo "<div><button onclick=location.href='edit.php?id=$id'>编辑</button></div>";
    echo "<div><button onclick='dodel($id)'>删除</button></div>";

}


// while ($row = mysqli_fetch_assoc($result)) {
//     echo "<p><a href=\"article.php?id={$row['id']}\">{$row['title']}</a>{$row['createtime']}</p>";
// }
?>
    
</body>
</html>

