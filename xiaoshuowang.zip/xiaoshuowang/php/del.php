<?php
session_start();
   if(@$_SESSION['isLogin']!=1){
    die( "没有登录");
  }
$id=$_POST['id'];
include 'function.php';
$sql="delete from essay where id=$id";
$affected=dml($sql);
if($affected==1){
echo "success" ;
}

?>
