<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        
        body{
            background-image:url(../../img/v2-5130cfea9846842946b58f303ce3774e_r.jpg);
            background-size:cover;

        }
        
        img{
        width: 200px;
        height: 200px;
        border-radius: 200px;
        
      } 
      .img{
        
        margin-top: 30px;
        margin-left: 50px;
        
      }     

        #div{
            border:0px solid gray;
            width:600px;
            height: 600px;
            margin:auto;
            margin-top:100px;
          
        }
        #div div{
            border:1px solid gray;
            width:14.5%;
            float:left;
            height:50px;

        }
        a {
      text-decoration: none;
    }
            
    </style>
    <script src="../html/jquery-3.4.1.min.js">
      </Script>
      <script> 
       function dodel(id){
            var param="ttid="+id;
            var confirmed=confirm('你确认要删除吗')
            if(confirmed){
            $.post(
                'del1.php',param,function(data){
                    if(data=='success'){
                        alert('删除成功')
                    }else{
                        alert('删除失败')
                    }
                    location.reload()
                }
            )
        }

        }
        function doedit(id){
            $.get(
                'edit.php?id='+id,function(data){
                    location.href='edit.php?id='+id
                }
            )
        }
    </script>
</head>
<body>
    <?php
 $id=$_GET['id'];
//  $con =mysqli_connect('127.0.0.1','root','','test');
//            mysqli_query($con,"set names utf8");
//            $sql="select ttid,tid,title1,content1,title from details,essay where details.id=essay.id and details.id=$id";
//             $res=mysqli_query($con,$sql);
//             mysqli_close($con);
//             foreach($res as $resault){
//                 $title1=$resault['title1'];}

 echo  "<div><input onclick=location.href='../html/essay1.php?id=$id' type='button' value='发布'></div>";
?>

 <div id="div">
        <label style="font-size:26px;text-align:center" for="">文章清单</label><br/>
    <div>编号</div>
    <div style="width:40%">章节名</div>
    <div>书名</div>
    <div>编辑</div>
    <div>删除</div>
        <?php
           
           $con =mysqli_connect('127.0.0.1','root','','test');
           mysqli_query($con,"set names utf8");
           $sql="select ttid,tid,title1,content1,title from details,essay where details.id=essay.id and details.id=$id";
            $res=mysqli_query($con,$sql);
            mysqli_close($con);
            foreach($res as $resault){
                $ttid=$resault['ttid'];
                $tid=$resault['tid'];
                $title=$resault['title'];
                $title1=$resault['title1'];
                $content=$resault['content1'];
                echo "<div>$tid</div>";
                echo "<div style='width:40%'>$title1</div>";
                echo "<div>$title</div>";
                echo "<div><button onclick=location.href='edit1.php?ttid=$ttid'>编辑</button></div>";
                echo "<div><button onclick='dodel($ttid)'>删除</button></div>";
            }





        ?>
</body>
</html>