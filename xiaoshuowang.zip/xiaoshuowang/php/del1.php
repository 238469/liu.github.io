<?php
session_start();
   if(@$_SESSION['isLogin']!=1){
    die( "没有登录");
  }
$id=$_POST['ttid'];
include 'function.php';
$sql="delete from details where ttid=$id";
$affected=dml($sql);
if($affected==1){
echo "success" ;
}

?>