
<?php

$content=$_POST['content'];
$title=$_POST['title'];
$id=$_POST['id'];
include 'function.php';
$sql="update essay set title='$title',content='$content' where id=$id";
$dml=dml($sql);
if($dml==1){
    echo "success";
}
?>