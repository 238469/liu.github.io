
<?php

$content=$_POST['content1'];
$title=$_POST['title1'];
$id=$_POST['ttid'];
include 'function.php';
$sql="update details set title1='$title',content1='$content' where ttid=$id";
$dml=dml($sql);
if($dml==1){
    echo "success";
}
?>