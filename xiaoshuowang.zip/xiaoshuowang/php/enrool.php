<?php
$username=$_POST['username'];
$password=$_POST['password'];
$tel=$_POST['tel'];
$repassword=$_POST['repassword'];
$role=$_POST['role'];
$file=@$_FILES['files'];
$pattern="/^1[3-9]\d{9}$/";
$phone=preg_match($pattern,$tel);
$filename=$file['tmp_name'];
$srcfile=$file['name'];
$to='upload/'.$srcfile;
@$move=move_uploaded_file($filename,$to);
$password1=md5($password);
if($password==$repassword && $phone==1){
$sql="insert into user values('','$username','$password1','$tel','$role',now(),'$srcfile')";
include 'function.php';
$dml=dml($sql);
if($dml==1){
        echo "success";
    }else{
    echo "注册失败";
    
}
}

?>