<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src='../tinymce/xixi/hah/tinymce.min.js' ></script>
    <script>
  tinymce.init({
    selector: '#mytextarea'
  });  
  </script>
    <style>
    body{
            background-image: url(../../img/v2-5130cfea9846842946b58f303ce3774e_r.jpg);
            background-size:cover
        } 
        label{ 
            text-align:center;
            margin-top:50px;
        }
        div{
            width: 100%;
            height: 100%;
            border:0px solid green;
            margin:auto;
            margin-top:100px;
            text-align: center;
        }
        textarea{
            margin-top:50px
        }
    </style>
</head>
<body>
    <?php
// 连接数据库
$conn = mysqli_connect('localhost', 'root', '', 'test');
if (!$conn) {
    die('连接数据库失败：' . mysqli_connect_error());
}
mysqli_query($conn,"set names utf8");
// 根据文章 ID 从数据库中获取文章的信息
$id = $_GET['id'];
$sql = "SELECT * FROM essay WHERE id=$id";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
mysqli_close($conn);
?>
<div>
<label style="font-size: 100px;"><?php echo $row['title']?><label><br>
<textarea name="" id="mytextarea" cols="100" rows="100"><?php echo $row['content']?></textarea>
</div>

</body>
</html>

