<?php
function dml($sql,$host="localhost",$user="root",$pwd='',$db='test'){
    $con=mysqli_connect($host,$user,$pwd,$db)or die("数据库连接不成功".mysqli_connect_error());
    mysqli_query($con,"set names utf8");
    $res=mysqli_query($con , $sql);
    mysqli_close($con);
    return $res;
    }
function prepare_dml($sql,$string,$user){
    $con=new mysqli('127.0.0.1','root','','test');
    // $sql="update user set password=? where username=?";
    $stmt=$con->prepare($sql);
    $stmt->bind_param($string,$user);
    $stmt->execute();
    $con->commit();
    $stmt->close();
    $con->close();
}

function prepare_sql($sql,$user){
    $con=new mysqli('127.0.0.1','root','','test');
    // $sql="select password from user where username= ?";
    $stmt=$con->prepare($sql);//预处理
    $stmt->bind_param('s',$user);//捆绑参数
    $stmt->execute();
    $con->commit();
    $stmt->bind_result($res);
    $stmt->fetch();//拿结果
    $stmt->close();
    $con->close();
    return $res;
}
?>