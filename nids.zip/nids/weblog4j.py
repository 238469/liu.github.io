import re
from scapy.all import *
from scapy.all import raw
import time
import datetime
import csv
from urllib.parse import unquote
import json
import netfilterqueue

dict2 = {}
ICMP_THRESHOLD = 100  # 设置 ICMP Echo Request 阈值
TIME_WINDOW = 10  # 时间窗口大小（单位：秒）
alerted = False
set1 = set()
# icmp重定向攻击 netwox 86 -g 192.168.184.144
# hping3 -q -n -a 10.0.01 -- id O-- icmp -d 142 -- flood 192.168.184.161 泛洪攻击
icmp_ty5_THRESHOLD = 20  # 重定向
TIME_WINDOW_icmp = 5  # 重定向

# 用于存储每个源 IP 地址接收到的 ICMP Echo Request 数据包数量和时间戳
icmp_count = {}

# 用于统计短时间内收到的 ICMP Echo Request 请求数量
icmp_request_count = 0
last_request_time = None

MAX_ICMP_SIZE = 100 # ICMP 数据包的最大大小

# SYN 验证命令 hping3 -c 1000 -d 120 -S -w 64 --flood --rand-source ip
syn_count = {}  # 用于存储每个源 IP 地址接收到的 SYN 请求计数和时间戳
SYN_THRESHOLD = 5000  # 设置 syn 阈值
# udp 验证命令hping3 --udp -p ip
udp_count = {}  # 用于存储每个源IP地址接收到的UDP数据包数量和时间戳
UDP_THRESHOLD = 15  # 设置UDP数据包阈值
TIME_WINDOW_udp = 22  # 重定向  假设 UDP_THRESHOLD 设置为 10，TIME_WINDOW_udp 设置为 10 秒。如果某个源IP地址在过去的10秒内接收到的UDP数据包数量超过了10个，那么就会判定为泛洪攻击，并输出相应的信息。
# arp 验证命令arpspoof -i eth0 -t 192.168.184.161 192.168.184.1
arp_count = {}
arp_THRESHOLD = 8
TIME_WINDOW_arp = 20



def http_handler(pkt):
    packet = IP(pkt.get_payload())
    detect_icmp(packet,pkt)
    detect_udp(packet,pkt)   
    detect_arp(packet,pkt)
    detect_syn(packet)
    if packet.haslayer(Raw) and TCP in packet:
        line = packet[Raw].load.decode('iso8859-1')  # 转成asill码
        sip = packet['IP'].src
        dip = packet['IP'].dst
        if ssh(packet,sip):
            pkt.drop()
            return
        if reids(packet,dip,line,sip):
            pkt.drop()
            return
        if mysql_check(packet,line,sip):
            pkt.drop()
            return
        if http_dispose(packet,line,sip,dip):
            pkt.drop()
            return


    pkt.accept()
def http_dispose(packet,line,sip,dip):
    if packet['TCP'].dport == 80:
        try:
            match1 = re.search('Referer:(.*)', line)  # 取出referer字段
            referer = match1.group(1).strip()
            if packet['TCP'].dst not in referer:  #
                write_log(sip,'drop','存在csrf利用')
        except:
            pass
        a = line.split(" ")[0]  # 空格截取取第一个请求方法
        if request_dispose(line, a, sip):
            return True
    elif packet['TCP'].sport == 80:
        if re.findall('HTTP/1.1', line):
            code = line.split(" ")[1]
            if code == '404':
                check(dip, '404状态码', 10)
def reids(packet,dip,line,sip):
    if packet['TCP'].dport == 6379:
        if re.search('config(\s|.)+set(\s|.)+dir(\s|.)*|config(\s|.)+set(\s|.)+dbfilename(\s|.)*', line,
                     re.IGNORECASE):
            write_log(sip,'drop','存在redis利用')
            return True
    elif packet['TCP'].sport == 6379:
        if re.search('-ERR invalid password', line):
            check(dip, 'reids密码爆破', 200,10 )
def ssh(packet,sip):
    if packet['TCP'].dport == 22:
        check(sip, 'ssh爆破', 300, 10)
def request_dispose(line, a, sip):
    if a == 'GET':
        url = line.split(" ")[1]
        if match(sip,url):
            return True
    elif a == 'POST':
        if re.search('Content-Disposition: form-data.*?filename=', line):
            body = line.split("\r\n\r\n")[-2].strip()
            if re.search(
                    'eval|system|passthru|shell_exec|exec|preg_replace|assert|base64|call_user_func|create_function|array_map|call_user_func_array|array_map|array_filter|usort|uasort|preg_replace|popen|proc_open',
                    body, re.IGNORECASE):
                write_log(sip,'drop','存在恶意文件上传')
                return True
        else:
            try:  
                body = line.split("\r\n\r\n")[1].strip()
                if match(sip,body):
                    return True
            except:
                pass
def check(ip, method, number=5, time=10):

    start_time = datetime.datetime.now()  # 获取当前时间
    if f'{ip}{method}' in dict2.keys():
        if start_time<dict2[f'{ip}{method}'][0]:
            return
        dict2[f'{ip}{method}'][1] = dict2[f'{ip}{method}'][1] + 1
    else:
        dict2[f'{ip}{method}'] = [start_time, 1]
    if dict2[f'{ip}{method}'][1] >= number:
        if (start_time - dict2[f'{ip}{method}'][0]).total_seconds() <= time:
            block_ip_address(ip,method)
            dict2[f'{ip}{method}'][0] = start_time+datetime.timedelta(seconds=60)
            dict2[f'{ip}{method}'][1] = 0
        else:
            dict2[f'{ip}{method}'][0] = start_time
            dict2[f'{ip}{method}'][1] = 0


def port_check(ip, method, port, number=5, time=10):
    start_time = datetime.datetime.now()  # 获取当前时
    if f'{ip}{method}' in dict2.keys():
        if start_time<dict2[f'{ip}{method}'][0]:
            return
        dict2[f'{ip}{method}'][1] = set1.add(port)
    else:
        dict2[f'{ip}{method}'] = [start_time, set1.add(port)]
    print(len(set1))
    if len(set1) >= number:
        if (start_time - dict2[f'{ip}{method}'][0]).total_seconds() <= time:
            print(method)
            block_ip_address(ip,method)
            dict2[f'{ip}{method}'][0] = start_time+datetime.timedelta(seconds=60)
            set1.clear()
        else:
            dict2[f'{ip}{method}'][0] = start_time
            set1.clear()


def mysql_check(packet,line, sip):
    if packet['TCP'].dport == 3306:
        match = re.search(
            'updatexml|load_file|into.*outfile|extractvalue|floor|geometrycollection|multipoint|polygon|multipolygon|linestring|multilinestring|exp',
            line, re.IGNORECASE)
        if match:
            write_log(sip,'drop','存在mysql敏感操作')
            return True
    elif packet['TCP'].sport == 3306:
        match = re.search('Access\s+denied\s+for\s+user', line, re.IGNORECASE)
        if match:
              write_log(sip,'accept','mysql登录失败')

def match(ip,data):  # 传入要进行匹配的数据
    # ruls = access_rules('poc')
    with open('ruls', 'r') as fp:
        ruls = fp.read()
    ruls = json.loads(ruls)
    data = unquote(data)  # 进行url解码然后重新赋值
    for rul in ruls:
        if re.search(rul['rul'], data, re.IGNORECASE):
            write_log(ip,'drop',rul['name'])
            print(rul['name'])
            return True

def write_log(ip,action,attacktype):
    data=f'ip.src:{ip} action:{action} time:{datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")} attacktype:{attacktype}'
    data=f"{data}\n"
    with open('log.txt','a')as fp:
        fp.write(data)
def detect_icmp(packet,pkt):
    global icmp_request_count
    global last_request_time
    global alerted

    if ICMP in packet and packet[ICMP].type == 8:  # ICMP Echo Request
        src_ip = packet[IP].src
        current_time = time.time()
        # 更新源 IP 地址的计数和时间戳
       
        if src_ip in icmp_count:
            if icmp_count[src_ip]["timestamp"]> current_time:
                return
            # 检查是否在时间窗口内
            if current_time - icmp_count[src_ip]["timestamp"] <= TIME_WINDOW:
                icmp_count[src_ip]["count"] += 1
            else:
                # 检查是否达到阈值
                if icmp_count[src_ip]["count"] > ICMP_THRESHOLD:
                    icmp_count[src_ip]["timestamp"] = current_time+60
                    icmp_count[src_ip]["count"] = 1
                    block_ip_address(src_ip, "icmp泛洪攻击")  # 调用函数进行封禁操作
                    # 超过时间窗口，重置计数和时间戳
                else:
                    icmp_count[src_ip]["count"] = 1
                    icmp_count[src_ip]["timestamp"] = current_time
        else:
            # 首次收到 ICMP Echo Request 数据包，初始化计数和时间戳
            icmp_count[src_ip] = {"count": 1, "timestamp": current_time}

        # 检查是否在时间窗口内
        if last_request_time is None or current_time - last_request_time > TIME_WINDOW:
            # 超过时间窗口，重置计数和时间戳
            icmp_request_count = 1
            last_request_time = current_time
            alerted = False  # 重置预警标志位
        else:
            icmp_request_count += 1

        # 检查是否达到阈值
        if icmp_request_count > ICMP_THRESHOLD:
            if not alerted:
                print("遭受 ICMP 泛洪攻击，短时间内接收到大量 ICMP Echo Request 请求")
                alerted = True

        # 检查 ICMP 数据包大小
        if len(packet[ICMP]) > MAX_ICMP_SIZE:
            if not alerted:
                write_log('','accept','icmp数据包异常')
                alerted = True

    elif ICMP in packet and packet[ICMP].type == 5:  # ICMP Redirect
        current_time = time.time()
        # 检查是否在时间窗口内
        if last_request_time is None or current_time - last_request_time > TIME_WINDOW_icmp:
            # 超过时间窗口，重置计数和时间戳
            icmp_request_count = 1
            last_request_time = current_time
            alerted = False  # 重置预警标志位
        else:
            icmp_request_count += 1

            # 检查是否达到阈值
            if icmp_request_count > icmp_ty5_THRESHOLD:
                if not alerted:
                    write_log('五ip','accept','icmp重定向攻击')
                    alerted = True

# 初始化标志位


alerted = False


def detect_syn(packet):
    if TCP in packet and packet[TCP].flags == 'S':  # 检查 TCP SYN 请求
        src_ip = packet[IP].src
        current_time = time.time()
        port_check(src_ip, '端口扫描', packet['TCP'].dport, 100, 10)  # 判断有没有端口扫描
        #更新源 IP 地址的计数和时间戳
      
        if src_ip in syn_count:
            if syn_count[src_ip]["timestamp"]> current_time:
                return
            # 检查是否在时间窗口内
            if current_time - syn_count[src_ip]["timestamp"] <= TIME_WINDOW:
                syn_count[src_ip]["count"] += 1
            else:
                # 超过时间窗口，发送预警并重置计数和时间戳
                if syn_count[src_ip]["count"] > SYN_THRESHOLD:
                    syn_count[src_ip]["count"] = 1
                    syn_count[src_ip]["timestamp"] = current_time+60
                    block_ip_address(src_ip, "tcp Flood")  # 调用函数进行封禁操作
                else:
                    syn_count[src_ip]["count"] = 1
                    syn_count[src_ip]["timestamp"] = current_time
        else:
            # 首次收到 SYN 请求，初始化计数和时间戳
            syn_count[src_ip] = {"count": 1, "timestamp": current_time}

def detect_udp(packet,pkt):
    
    
    if UDP in packet:
        try:
            src_ip = packet[IP].src
            current_time = time.time()
            # 更新源IP地址的计数和时间戳
            if src_ip in udp_count:
                if udp_count[src_ip]["timestamp"]> current_time:
                    return
                # 检查是否在时间窗口内
                if current_time - udp_count[src_ip]["timestamp"] <= TIME_WINDOW_udp:
                    udp_count[src_ip]["count"] += 1
                else:
                    # 检查是否达到阈值
                    if udp_count[src_ip]["count"] > UDP_THRESHOLD:
                        udp_count[src_ip]["timestamp"] = current_time+60
                        udp_count[src_ip]["count"] = 1
                        block_ip_address(src_ip, "UDP Flood")  # 调用函数进行封禁操
                    else:
                        udp_count[src_ip]["count"] = 1
                        udp_count[src_ip]["timestamp"] = current_time
            else:
                # 首次收到UDP数据包，初始化计数和时间戳
                udp_count[src_ip] = {"count": 1, "timestamp": current_time}

        except:
            pass



def detect_arp(packet,pkt):
    if ARP in packet:
        src_mac = packet[ARP].hwsrc  # 因为ARP协议位于网络层之下，而不是在IP层。
        # print(src_ip)
        # print(src_mac)
        # 更新MAC地址的计数和时间戳
        if packet['ARP'].op == 2:
            if src_mac in arp_count:
                current_time = time.time()
                # 检查是否在时间窗口内
                if current_time - arp_count[src_mac]["timestamp"] <= TIME_WINDOW_arp:
                    arp_count[src_mac]["count"] += 1
                else:
                    # 检查是否达到阈值
                    if arp_count[src_mac]["count"] > arp_THRESHOLD:
                        write_log(src_mac,'accept','arp攻击')
                    # 超过时间窗口，重置计数和时间戳
                    arp_count[src_mac]["count"] = 1
                    arp_count[src_mac]["timestamp"] = current_time
            else:
                # 首次收到ARP数据包，初始化计数和时间戳
                arp_count[src_mac] = {"count": 1, "timestamp": time.time()}

# # sniff(iface="ens33",filter="tcp and host 192.168.150.206 or icmp or arp or udp",prn=mysql_packet)

def block_ip_address(ip_address, attack_type):
    # 检查IP地址是否已被封禁
    # 添加一个iptables规则来封禁IP地址
    # command = f"timeout 60 iptables -I INPUT -s {ip_address} -j DROP"
    # subprocess.run(command, shell=True, check=True)

    print(f"已封禁IP地址：{ip_address}，攻击类型：{attack_type}")
    write_log(ip_address,'drop',f'防火墙封禁攻击类型{attack_type}')
if __name__ == '__main__':
    # 创建netfilterqueue实例对象
    filter = netfilterqueue.NetfilterQueue()
    # 将监听队列1与http_handler绑定，将拦截的包传入该函数中
    filter.bind(1, http_handler)
    # 运行netfilterqueue，进行数据包拦截
    filter.run()

