<?php
session_start();
getCode();
function getCode($vlen=4,$width=80,$height=30){
    //定义响应类型为png图片
    header("content-type:image/png");
    //生成随机验证码字符串，并将其保存在Session
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $vcode = substr(str_shuffle($chars), 0, $vlen);
    //将生成的随机验证码字符串保存在Session变量中，供登录后对比
   

    //定义图片并设置颜色
    $image=imagecreate($width,$height);
    $imgColor=imagecolorallocate($image,255,255,255);

    //以rgb=0,0,0的颜色绘制黑色文字
    $color=imagecolorallocate($image,0,0,0);
    imagestring($image,5,20,5,$vcode,$color);

    $fontFile = 'E:/sql/Demonized/Demonized-1.ttf';

    //生成一批随机位置干扰点
    for ($i=0;$i<50;$i++){
        imagesetpixel($image,rand(0,$width),rand(0,$height),$color);
    }
    
    //输出验证码
    imagepng($image);
    imagedestroy($image); 
    $_SESSION['vcode']=$vcode;
}
?>