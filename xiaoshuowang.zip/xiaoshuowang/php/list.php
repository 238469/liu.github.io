<?php
 session_start();
 if(@$_SESSION['isLogin']!=1){
  die('未登录');
 }
  // 连接数据库
$conn = mysqli_connect('localhost', 'root', '', 'test');
if (!$conn) {
  die('连接数据库失败：' . mysqli_connect_error());
}

// 从数据库中获取所有已发布的文章
mysqli_query($conn,"set names utf8");
$sql = "select * from essay";

$result = mysqli_query($conn, $sql);
$res=mysqli_fetch_all($result,MYSQLI_ASSOC);

mysqli_close($conn);
echo json_encode($res);
?>