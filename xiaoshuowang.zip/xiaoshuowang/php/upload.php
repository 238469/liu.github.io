<?php
$url="www.baddu.com";
$contents=file_get_contents($url);
$html=new DOMDocument();
$html->loadHTML($contents);
$nodes=$html->getElementsByTagName('a');
$nodes->attributes

?>