<?php
$uid=$_POST['uid'];
$content=$_POST['content'];
$title=$_POST['title'];
$username=$_POST['username'];
include 'function.php';
$sq2="select * from user where uid=$uid ";
$sql="insert into essay values('','$title','$content',$uid,now())";
$dml=dml($sql);
$res=dml($sq2);
$resault=@mysqli_fetch_assoc($res)['role'];
if ($dml==1){
if($resault==1){
echo"$username";}elseif($resault==0){echo "$username";}
}

?>