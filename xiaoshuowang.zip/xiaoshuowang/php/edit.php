<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="../html/jquery-3.4.1.min.js"></Script>
    <script src='../tinymce/xixi/hah/tinymce.min.js' ></script>
    <script>

        function doedit(id){
            var title=$('#title').val();
            var content=tinymce.activeEditor.getContent();
            var rename="title="+title+"&content="+content+"&id="+id
            $.post(
                'doedit.php',rename,function(data){
                    
            }
            )
        }
        tinymce.init({
    selector: '#mytextarea'
  });

    </script>
      <style>
        div{
            width: 100%; 
            margin:auto;
            text-align: center;
            margin-top: 100px;
           
        }
        body{
            background-image:url(../../img/v2-5130cfea9846842946b58f303ce3774e_r.jpg);
            background-size:cover;
            
        }
        
        input{
            width:200px;
            height:40px;
        }
        textarea{
            margin-top:20px
        } 
        </style>
</head>
<body>
    <?php
    session_start();
    if(@$_SESSION['isLogin']!=1){
  die( "没有登录");
}

    $id=$_GET['id'];
  $conn = mysqli_connect('localhost', 'root', '', 'test');
  if (!$conn) {
      die('连接数据库失败：' . mysqli_connect_error());
  }
  
  // 从数据库中获取所有已发布的文章
  mysqli_query($conn,"set names utf8");
  $sql = "select  * from essay where id=$id";
  
  $result = mysqli_query($conn, $sql);
  $row=mysqli_fetch_assoc($result);
  mysqli_close($conn);
    ?><div><div style="font-size:50px">文章编辑</div>
    <input type="text" maxlength="15" name="title" id="title" value=<?php echo $row['title']?>><br>
    <textarea name="content" id="mytextarea" cols="100" rows="100" ><?php echo $row['content']?></textarea><br>
    <input type="button" onclick="doedit(<?php echo $id ?>)" value=提交></div>
 
</body>
</html>
