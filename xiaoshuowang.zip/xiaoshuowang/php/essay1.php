<?php
$id=$_POST['id'];
$content=$_POST['content'];
$tid=$_POST['tid'];
$title=$_POST['title'];
include 'function.php';
$sql="insert into details values('',$tid,$id,'$content','$title')";
$dml=dml($sql);
if ($dml==1){
echo "成功";
}

?>