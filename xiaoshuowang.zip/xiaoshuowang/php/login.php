<?php
session_start();
//  $captcha=$_POST['captcha'];
$username=$_POST['username'];
$vcode=$_POST['code'];
$password=@$_POST['password'];
$password1=md5($password);
//万能验证码
if(strtoupper($_SESSION['vcode'])!=strtoupper($vcode)){
    die("code errol");
}else{unset($_SESSION['vcode']);}
unset($_SESSION['vcode']);
//addslashes()转义
$username=addslashes($username);
$sql="select * from user where username='$username' ";
include 'function.php';
$res=dml($sql);
$num=mysqli_num_rows($res);
$res1=mysqli_fetch_assoc($res);
if ($num==1){
if ($res1['password']==$password){
        echo"success"; $_SESSION['isLogin']=true;}
       
    }else{
        echo '失败';
    }

// $res=dml($sql);
// $res1=mysqli_num_rows($res);
// $resault=@mysqli_fetch_assoc($res)['role'];
// if($res1==1){
// if($resault==1){
// echo"success"; $_SESSION['isLogin']=true;}elseif($resault==0){echo "success1";$_SESSION['isLogin']=true;;

// }}else{
//     echo 'fail';
// }
?>